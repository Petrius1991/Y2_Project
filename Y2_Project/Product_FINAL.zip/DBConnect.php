<?php
$mySQLconnection = @mysql_connect("79.170.40.235", "cl22-codeclub", "G/Jcz3b!s");
$database = "cl22-codeclub";
$table = "tbl_users";

?>